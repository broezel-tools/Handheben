# Rednerliste ✋ (GitHub Pages)

Digitale Handmeldung für den Unterricht. Die Moderation startet eine Sitzung und zeigt QR-Code oder Link, Schüler:innen melden sich mit dem Handy, die Moderation ruft der Reihe nach auf.

Eine einzige Datei (`index.html`), kein PHP, keine Datenbank. Die Liste liegt im Browser der Moderation. Die Geräte tauschen Nachrichten über Supabase Realtime (Broadcast) aus. Dabei wird nichts gespeichert.

## Einrichten

**1. Supabase-Projekt anlegen** (kostenlos, supabase.com)
- Neues Projekt, Region *Frankfurt (eu-central-1)* wählen
- *Project Settings → API*: **Project URL** und **anon public key** kopieren

**2. Zugangsdaten eintragen**
- `index.html` öffnen, oben im Abschnitt `RL_CONFIG` URL und Key eintragen
- Der anon-Key ist zur Veröffentlichung gedacht. Den `service_role`-Key niemals eintragen.

**3. Auf GitHub Pages veröffentlichen**
- Repo anlegen (public), `index.html` hochladen
- *Settings → Pages → Deploy from a branch → main → / (root)*
- Adresse: `https://NAME.github.io/REPO/`

Ohne Zugangsdaten läuft die Datei im **Demo-Modus** (nur Fenster im selben Browser), zum Ausprobieren.

## Hinweise

- Das Moderationsfenster muss geöffnet bleiben. Nach einem versehentlichen Neuladen läuft die Sitzung weiter.
- Sitzungen liegen 6 Stunden im Browser der Moderation, danach werden sie verworfen.
- Wer den Sitzungscode kennt, kann teilnehmen. Ein Schutz gegen absichtliche Störungen ist nicht vorgesehen.
- Kostenlose Supabase-Projekte können nach einer Woche ohne Aktivität pausiert werden (im Dashboard wieder aktivierbar).
- Datenschutz: Die Namen laufen kurz über Supabase-Server. Am besten nur Vornamen verwenden lassen und den Einsatz mit der Schulleitung bzw. dem Datenschutzbeauftragten klären.
